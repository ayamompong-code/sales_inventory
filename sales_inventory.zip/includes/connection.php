<?php
date_default_timezone_set("Asia/Jakarta");

$db = mysqli_connect("localhost", "root", "", "sales_inventory_db");

if (!$db) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>
