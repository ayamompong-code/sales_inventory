<?php
header("Content-Type: application/json");
require_once "../includes/connection.php";

$result = mysqli_query($db, "SELECT * FROM category");
echo json_encode(mysqli_fetch_all($result, MYSQLI_ASSOC));
