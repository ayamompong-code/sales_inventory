<?php
header("Content-Type: application/json");
require_once "../includes/connection.php";

/* ========= GET ========= */
if ($_SERVER['REQUEST_METHOD'] === "GET") {
    $result = mysqli_query($db, "SELECT * FROM customer");
    echo json_encode(mysqli_fetch_all($result, MYSQLI_ASSOC));
}

/* ========= POST ========= */
if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $data = json_decode(file_get_contents("php://input"), true);
    mysqli_query($db,"
        INSERT INTO customer (name, phone)
        VALUES ('{$data['name']}', '{$data['phone']}')
    ");
    echo json_encode(["message"=>"Customer ditambahkan"]);
}
