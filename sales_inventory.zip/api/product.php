<?php
header("Content-Type: application/json");
require_once "../includes/connection.php";

$method = $_SERVER['REQUEST_METHOD'];

/* ========= GET PRODUCT ========= */
if ($method === "GET") {
    $result = mysqli_query($db, "SELECT * FROM product");
    echo json_encode(mysqli_fetch_all($result, MYSQLI_ASSOC));
}

/* ========= POST PRODUCT ========= */
if ($method === "POST") {
    $data = json_decode(file_get_contents("php://input"), true);
    mysqli_query($db,"
        INSERT INTO product (name, category_id, price)
        VALUES ('{$data['name']}', '{$data['category_id']}', '{$data['price']}')
    ");
    echo json_encode(["message"=>"Produk ditambahkan"]);
}
